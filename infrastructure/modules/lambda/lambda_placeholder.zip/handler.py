import json

def lambda_handler(event, context):
    print("Retraining trigger received:", json.dumps(event))
    return {"statusCode": 200, "body": "OK"}
